--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "github test";
--
-- Name: github test; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "github test" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE "github test" OWNER TO postgres;

\connect -reuse-previous=on "dbname='github test'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account (
    user_id integer NOT NULL,
    account_number integer NOT NULL,
    account_type character varying(50) NOT NULL
);


ALTER TABLE public.account OWNER TO postgres;

--
-- Name: account_account_number_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_account_number_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.account_account_number_seq OWNER TO postgres;

--
-- Name: account_account_number_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_account_number_seq OWNED BY public.account.account_number;


--
-- Name: account_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.account_user_id_seq OWNER TO postgres;

--
-- Name: account_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_user_id_seq OWNED BY public.account.user_id;


--
-- Name: advertisements_page; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.advertisements_page (
    page_id integer NOT NULL,
    bounce_rate numeric(3,2),
    click_through_rate numeric(3,2),
    conversion_rate numeric(3,2)
);


ALTER TABLE public.advertisements_page OWNER TO postgres;

--
-- Name: advertisements_page_page_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.advertisements_page_page_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.advertisements_page_page_id_seq OWNER TO postgres;

--
-- Name: advertisements_page_page_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.advertisements_page_page_id_seq OWNED BY public.advertisements_page.page_id;


--
-- Name: business_account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.business_account (
    account_number integer NOT NULL,
    company_name character varying(50) NOT NULL,
    monthly_fee numeric(4,2)
);


ALTER TABLE public.business_account OWNER TO postgres;

--
-- Name: business_account_account_number_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.business_account_account_number_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.business_account_account_number_seq OWNER TO postgres;

--
-- Name: business_account_account_number_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.business_account_account_number_seq OWNED BY public.business_account.account_number;


--
-- Name: page; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.page (
    page_id integer NOT NULL,
    account_number integer NOT NULL,
    page_name character varying(50),
    number_of_visits integer
);


ALTER TABLE public.page OWNER TO postgres;

--
-- Name: page_account_number_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.page_account_number_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.page_account_number_seq OWNER TO postgres;

--
-- Name: page_account_number_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.page_account_number_seq OWNED BY public.page.account_number;


--
-- Name: page_page_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.page_page_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.page_page_id_seq OWNER TO postgres;

--
-- Name: page_page_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.page_page_id_seq OWNED BY public.page.page_id;


--
-- Name: personal_account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personal_account (
    account_number integer NOT NULL,
    id integer,
    name character varying(50) NOT NULL,
    date_of_birth character varying(50),
    email character varying(50) NOT NULL
);


ALTER TABLE public.personal_account OWNER TO postgres;

--
-- Name: personal_account_account_number_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.personal_account_account_number_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.personal_account_account_number_seq OWNER TO postgres;

--
-- Name: personal_account_account_number_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.personal_account_account_number_seq OWNED BY public.personal_account.account_number;


--
-- Name: usertable; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usertable (
    id integer NOT NULL,
    name character(50) NOT NULL,
    date_of_birth character varying(50),
    email character varying(50) NOT NULL
);


ALTER TABLE public.usertable OWNER TO postgres;

--
-- Name: account user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account ALTER COLUMN user_id SET DEFAULT nextval('public.account_user_id_seq'::regclass);


--
-- Name: account account_number; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account ALTER COLUMN account_number SET DEFAULT nextval('public.account_account_number_seq'::regclass);


--
-- Name: advertisements_page page_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertisements_page ALTER COLUMN page_id SET DEFAULT nextval('public.advertisements_page_page_id_seq'::regclass);


--
-- Name: business_account account_number; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.business_account ALTER COLUMN account_number SET DEFAULT nextval('public.business_account_account_number_seq'::regclass);


--
-- Name: page page_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page ALTER COLUMN page_id SET DEFAULT nextval('public.page_page_id_seq'::regclass);


--
-- Name: page account_number; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page ALTER COLUMN account_number SET DEFAULT nextval('public.page_account_number_seq'::regclass);


--
-- Name: personal_account account_number; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_account ALTER COLUMN account_number SET DEFAULT nextval('public.personal_account_account_number_seq'::regclass);


--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account (user_id, account_number, account_type) FROM stdin;
\.
COPY public.account (user_id, account_number, account_type) FROM '$$PATH$$/4833.dat';

--
-- Data for Name: advertisements_page; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.advertisements_page (page_id, bounce_rate, click_through_rate, conversion_rate) FROM stdin;
\.
COPY public.advertisements_page (page_id, bounce_rate, click_through_rate, conversion_rate) FROM '$$PATH$$/4842.dat';

--
-- Data for Name: business_account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.business_account (account_number, company_name, monthly_fee) FROM stdin;
\.
COPY public.business_account (account_number, company_name, monthly_fee) FROM '$$PATH$$/4835.dat';

--
-- Data for Name: page; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.page (page_id, account_number, page_name, number_of_visits) FROM stdin;
\.
COPY public.page (page_id, account_number, page_name, number_of_visits) FROM '$$PATH$$/4840.dat';

--
-- Data for Name: personal_account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.personal_account (account_number, id, name, date_of_birth, email) FROM stdin;
\.
COPY public.personal_account (account_number, id, name, date_of_birth, email) FROM '$$PATH$$/4837.dat';

--
-- Data for Name: usertable; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usertable (id, name, date_of_birth, email) FROM stdin;
\.
COPY public.usertable (id, name, date_of_birth, email) FROM '$$PATH$$/4830.dat';

--
-- Name: account_account_number_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_account_number_seq', 12, true);


--
-- Name: account_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_user_id_seq', 1, false);


--
-- Name: advertisements_page_page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.advertisements_page_page_id_seq', 1, false);


--
-- Name: business_account_account_number_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.business_account_account_number_seq', 1, false);


--
-- Name: page_account_number_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.page_account_number_seq', 1, true);


--
-- Name: page_page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.page_page_id_seq', 20, true);


--
-- Name: personal_account_account_number_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.personal_account_account_number_seq', 1, false);


--
-- Name: account account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_pkey PRIMARY KEY (account_number);


--
-- Name: advertisements_page advertisements_page_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertisements_page
    ADD CONSTRAINT advertisements_page_pkey PRIMARY KEY (page_id);


--
-- Name: business_account business_account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.business_account
    ADD CONSTRAINT business_account_pkey PRIMARY KEY (account_number);


--
-- Name: page page_page_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page
    ADD CONSTRAINT page_page_name_key UNIQUE (page_name);


--
-- Name: page page_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page
    ADD CONSTRAINT page_pkey PRIMARY KEY (page_id);


--
-- Name: personal_account personal_account_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_account
    ADD CONSTRAINT personal_account_id_key UNIQUE (id);


--
-- Name: personal_account personal_account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_account
    ADD CONSTRAINT personal_account_pkey PRIMARY KEY (account_number);


--
-- Name: usertable usertable_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usertable
    ADD CONSTRAINT usertable_pkey PRIMARY KEY (id);


--
-- Name: advertisements_page advertisements_page_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertisements_page
    ADD CONSTRAINT advertisements_page_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.page(page_id);


--
-- Name: business_account business_account_account_number_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.business_account
    ADD CONSTRAINT business_account_account_number_fkey FOREIGN KEY (account_number) REFERENCES public.account(account_number);


--
-- Name: page page_account_number_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page
    ADD CONSTRAINT page_account_number_fkey FOREIGN KEY (account_number) REFERENCES public.account(account_number);


--
-- Name: personal_account personal_account_account_number_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_account
    ADD CONSTRAINT personal_account_account_number_fkey FOREIGN KEY (account_number) REFERENCES public.account(account_number);


--
-- PostgreSQL database dump complete
--

